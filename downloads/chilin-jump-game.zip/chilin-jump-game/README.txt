小小發明家跳跳關　原檔
====================

同一套檔案，電腦、iPad、iPhone 都可以玩，不用分開三個版本。

【電腦】
1. 解壓這個資料夾
2. 用 Chrome 或 Safari 打開 index.html

【iPad／iPhone】
1. 下載後用「檔案」App 解壓
2. 點 index.html，用 Safari 開啟
3. 想一撳就玩：上網打開遊戲後，Safari 分享 → 加入主畫面

【成績】
離線打開的原檔不會把分數交給老師。
要交功課請用網站或掃二維碼上網玩。

遊戲網址（長期有效）：
https://cheungsiredu.github.io/chilin-jump-game/
