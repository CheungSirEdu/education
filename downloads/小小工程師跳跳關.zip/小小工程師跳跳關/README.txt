小小工程師跳跳關
================

本檔案適用於電腦、平板電腦及智能電話。

【電腦】
1. 解壓縮此資料夾
2. 以 Chrome 或 Safari 開啟 index.html

【平板電腦／智能電話】
1. 下載後以「檔案」應用程式解壓縮
2. 點選 index.html，以 Safari 開啟

遊戲網址：
https://cheungsiredu.github.io/education/engineer/
